AIWA V13 — GitHub Pages (отдельный тестовый сайт)

1. Создайте НОВЫЙ публичный репозиторий GitHub, например aiwa-test-catalog. НЕ используйте рабочий aiwa-mini-app.
2. Загрузите СОДЕРЖИМОЕ этого ZIP в корень репозитория (index.html и папку assets), не сам ZIP.
3. Откройте Settings > Pages > Build and deployment > Deploy from a branch.
4. Выберите branch main и folder /(root), нажмите Save.
5. Адрес обычно будет https://ВАШ-ЛОГИН.github.io/aiwa-test-catalog/ после публикации.

ВНИМАНИЕ: репозиторий и файлы публичны. Автоматической серверной отправки в Telegram нет; заявка копируется вручную. Основной сайт Netlify не меняется.
